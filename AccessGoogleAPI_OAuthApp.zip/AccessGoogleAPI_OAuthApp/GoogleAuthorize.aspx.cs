﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Gmail.v1;
using Google.Apis.Util.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AccessGoogleAPI_OAuthApp
{
    public partial class GoogleAut : System.Web.UI.Page
    {

        public static string ApplicationName = "Google API Using Oauth2 Client1";
        public static string ClientId = "1058951775800-9irkqcoa2nc4qsjclb5ellvr1me2282s.apps.googleusercontent.com";
        public static string ClientSecret = "lD7pObeIPg_KVwnuHXrfQUxS";


        public static string[] Scopes =
        {
            GmailService.Scope.GmailCompose,
            GmailService.Scope.GmailSend
        };

        public static UserCredential GetUserCredential(out string error)
        {
            UserCredential credential = null;
            error = string.Empty;

            try
            {
                credential = GoogleWebAuthorizationBroker.AuthorizeAsync(

                    new ClientSecrets
                    {
                        ClientId = ClientId,
                        ClientSecret = ClientSecret
                    },
                    Scopes,
                    Environment.UserName,
                    CancellationToken.None,
                    new FileDataStore("Google Oaut2 Client Application")

                    ).Result;
            }
            catch(Exception ex)
            {
                credential = null;
                error = "Failed user credential initialization: " + ex.ToString();
               
            }
            return credential;
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAuthorize_Click(object sender, EventArgs e)
        {
            string credentialError = string.Empty;
            string refreshToken = string.Empty;

            UserCredential credential = GetUserCredential(out credentialError);

            if (credential != null && string.IsNullOrWhiteSpace(credentialError))
            {
                refreshToken = credential.Token.RefreshToken;
            }

        }
    }
}